# Real-Time Chat App

A full-stack starter chat application with live messaging, online presence, typing indicators, read receipts, message history, and file uploads.

## Tech stack
- Frontend: React + Vite
- Backend: Node.js + Express
- Real-time: Socket.IO
- Database: PostgreSQL
- Optional scaling: Redis adapter (instructions below)

## Requirements
Node.js 20+ and PostgreSQL 14+.

## Quick start
1. Create a PostgreSQL database named `realtime_chat`.
2. In `server/`, copy `.env.example` to `.env` and set `DATABASE_URL`.
3. From this folder run:
   ```bash
   npm run install:all
   npm run dev
   ```
4. Open http://localhost:5173 in two browser tabs. Use different display names to test chatting.

The server creates the messages table automatically. This starter uses a simple display-name identity for local development; add authentication before exposing it publicly.

## Production checklist
- Add real authentication and authorization (never trust a client-supplied user ID).
- Put the app behind HTTPS and configure `CLIENT_ORIGIN`.
- Store uploads in S3-compatible object storage instead of local disk.
- Add rate limits, moderation, malware scanning, and upload quotas.
- Use managed PostgreSQL backups and migrations.
- For multiple server instances, add the Socket.IO Redis adapter and sticky sessions where required.

## API
- `GET /api/health` — health check
- `GET /api/messages?limit=50` — recent message history
- `POST /api/upload` — upload a file (multipart field `file`)

## Socket events
Client -> server: `chat:message`, `chat:typing`, `chat:read`
Server -> client: `chat:message`, `presence:update`, `chat:typing`, `chat:read`
