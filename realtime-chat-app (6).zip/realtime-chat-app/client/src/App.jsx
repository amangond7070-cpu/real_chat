import { useCallback, useEffect, useRef, useState } from 'react';
import { io } from 'socket.io-client';
import { Paperclip, Send, Smile, Search, MoreHorizontal, MessageCircle, CheckCheck, Circle, X, FileText, LogOut } from 'lucide-react';

const API = import.meta.env.VITE_API_URL || 'http://localhost:4000';
const socket = io(API, { autoConnect: false });
const initials = (name = '?') => name.split(/\s+/).map((p) => p[0]).join('').slice(0, 2).toUpperCase();
const colors = ['#7c5cff', '#e879a9', '#1e9b8a', '#e09f3e', '#4c8bf5'];
const avatarColor = (name = '') => colors[[...name].reduce((sum, c) => sum + c.charCodeAt(0), 0) % colors.length];
const formatTime = (value) => new Date(value).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

export default function App() {
  const [name, setName] = useState(localStorage.getItem('orbit-name') || '');
  const [draftName, setDraftName] = useState(localStorage.getItem('orbit-name') || '');
  const [joined, setJoined] = useState(false);
  const [messages, setMessages] = useState([]);
  const [online, setOnline] = useState([]);
  const [typing, setTyping] = useState([]);
  const [draft, setDraft] = useState('');
  const [search, setSearch] = useState('');
  const [upload, setUpload] = useState(null);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState('');
  const bottomRef = useRef(null);
  const fileRef = useRef(null);
  const typingTimer = useRef(null);

  const join = useCallback(async (event) => {
    event?.preventDefault();
    const clean = draftName.trim().slice(0, 32);
    if (!clean) return;
    localStorage.setItem('orbit-name', clean);
    setName(clean); setJoined(true); setError('');
    try {
      const res = await fetch(`${API}/api/messages?limit=60`);
      if (!res.ok) throw new Error('Could not load message history. Is the server running?');
      setMessages(await res.json());
    } catch (e) { setError(e.message); }
    if (!socket.connected) socket.connect();
    socket.emit('user:join', clean);
  }, [draftName]);

  useEffect(() => {
    const onMessage = (message) => setMessages((old) => old.some((m) => m.id === message.id || (m.clientId && m.clientId === message.clientId)) ? old.map((m) => (m.id === message.id || m.clientId === message.clientId) ? { ...m, ...message } : m) : [...old, message]);
    const onPresence = (users) => setOnline(users);
    const onTyping = ({ name: who, typing: active }) => setTyping((old) => active ? [...new Set([...old.filter((x) => x !== who), who])] : old.filter((x) => x !== who));
    const onRead = ({ id, readBy }) => setMessages((old) => old.map((m) => String(m.id) === String(id) ? { ...m, readBy } : m));
    socket.on('chat:message', onMessage); socket.on('presence:update', onPresence); socket.on('chat:typing', onTyping); socket.on('chat:read', onRead);
    return () => { socket.off('chat:message', onMessage); socket.off('presence:update', onPresence); socket.off('chat:typing', onTyping); socket.off('chat:read', onRead); clearTimeout(typingTimer.current); };
  }, []);

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages, typing]);

  useEffect(() => {
    if (!joined) return;
    messages.filter((m) => m.sender !== name && m.id && !(m.readBy || []).includes(name)).forEach((m) => socket.emit('chat:read', m.id));
  }, [messages, joined, name]);

  const sendMessage = async (event) => {
    event?.preventDefault();
    if (sending || (!draft.trim() && !upload)) return;
    setSending(true); setError('');
    try {
      let fileData = null;
      if (upload) {
        const form = new FormData(); form.append('file', upload);
        const response = await fetch(`${API}/api/upload`, { method: 'POST', body: form });
        const data = await response.json(); if (!response.ok) throw new Error(data.error || 'File upload failed');
        fileData = { fileUrl: `${API}${data.url}`, fileName: data.name };
      }
      const payload = { clientId: crypto.randomUUID(), body: draft.trim(), ...fileData };
      socket.emit('chat:message', payload, (response) => { if (response?.error) setError(response.error); });
      setDraft(''); setUpload(null); socket.emit('chat:typing', false);
    } catch (e) { setError(e.message); }
    finally { setSending(false); }
  };

  const onDraft = (value) => {
    setDraft(value); socket.emit('chat:typing', Boolean(value.trim()));
    clearTimeout(typingTimer.current); typingTimer.current = setTimeout(() => socket.emit('chat:typing', false), 1200);
  };
  const visibleMessages = messages.filter((m) => `${m.sender} ${m.body} ${m.fileName || ''}`.toLowerCase().includes(search.toLowerCase()));

  if (!joined) return <main className="join-screen"><div className="join-card"><div className="brand-mark large"><MessageCircle size={28}/></div><p className="eyebrow">YOUR SPACE TO CONNECT</p><h1>Good conversations<br/><span>start here.</span></h1><p className="muted">Join the room and start chatting in real time.</p><form onSubmit={join}><label htmlFor="display-name">Your display name</label><input id="display-name" autoFocus maxLength={32} placeholder="e.g. Aman" value={draftName} onChange={(e) => setDraftName(e.target.value)}/><button className="primary full" type="submit">Enter chat <Send size={16}/></button></form>{error && <p className="error">{error}</p>}<p className="fine-print">Demo mode · Use two tabs to test live chat</p></div></main>;

  return <main className="app-shell"><aside className="sidebar"><div className="side-brand"><div className="brand-mark"><MessageCircle size={21}/></div><span>orbit<span className="brand-dot">.</span></span><button className="icon-btn side-more" title="More"><MoreHorizontal size={21}/></button></div><div className="workspace-label">WORKSPACE <span>01</span></div><div className="room active-room"><div className="room-icon"><MessageCircle size={18}/></div><div><strong>General chat</strong><small>Everyone is welcome</small></div><span className="room-dot"/></div><div className="side-section"><span>DIRECT MESSAGES</span><button className="icon-btn" title="Add conversation">+</button></div><div className="people-list">{online.filter((u) => u !== name).map((person) => <div className="person-row" key={person}><div className="avatar small" style={{ background: avatarColor(person) }}>{initials(person)}<i/></div><span>{person}</span></div>)}{online.filter((u) => u !== name).length === 0 && <p className="side-empty">No one else here yet</p>}</div><div className="sidebar-bottom"><div className="avatar" style={{ background: avatarColor(name) }}>{initials(name)}</div><div className="profile-info"><strong>{name}</strong><small><i className="online-dot"/> Active now</small></div><button className="icon-btn logout" title="Leave chat" onClick={() => { socket.disconnect(); setJoined(false); setDraftName(name); }}><LogOut size={17}/></button></div></aside>

  <section className="chat-panel"><header className="chat-header"><div className="header-room-icon"><MessageCircle size={21}/></div><div className="header-title"><h2>General chat</h2><p><span className="online-dot"/> {online.length} {online.length === 1 ? 'member' : 'members'} online</p></div><div className="header-actions"><div className="search-box"><Search size={16}/><input aria-label="Search messages" placeholder="Search messages..." value={search} onChange={(e) => setSearch(e.target.value)}/>{search && <button className="icon-btn" onClick={() => setSearch('')} title="Clear search"><X size={14}/></button>}</div><button className="icon-btn header-more" title="More options"><MoreHorizontal size={22}/></button></div></header>
  <div className="conversation"><div className="welcome-banner"><div className="welcome-spark">✳</div><div><strong>Welcome to General chat</strong><p>This is the beginning of something good. Say hello!</p></div></div><div className="date-divider"><span>MESSAGES</span></div>
  {visibleMessages.map((m, index) => { const mine = m.sender === name; const prev = visibleMessages[index - 1]; const grouped = prev?.sender === m.sender && new Date(m.createdAt) - new Date(prev.createdAt) < 300000; return <article className={`message-row ${mine ? 'mine' : ''} ${grouped ? 'grouped' : ''}`} key={m.id || m.clientId || index}>{!grouped && <div className="avatar message-avatar" style={{ background: avatarColor(m.sender) }}>{initials(m.sender)}</div>}<div className="message-content">{!grouped && <div className="message-meta"><strong>{mine ? 'You' : m.sender}</strong><time>{formatTime(m.createdAt)}</time></div>}{m.body && <div className="message-bubble">{m.body}</div>}{m.fileUrl && <a className="file-attachment" href={m.fileUrl} target="_blank" rel="noreferrer">{m.fileName?.match(/\.(png|jpe?g|gif|webp)$/i) ? <img src={m.fileUrl} alt={m.fileName}/> : <><span className="file-icon"><FileText size={20}/></span><span><strong>{m.fileName || 'Attachment'}</strong><small>Click to open file</small></span></>}</a>}{mine && <div className="read-status">{(m.readBy || []).some((u) => u !== name) ? <><CheckCheck size={14}/> Seen</> : <><CheckCheck size={14}/> Sent</>}</div>}</div></article>; })}
  {typing.filter((u) => u !== name).length > 0 && <div className="typing-row"><div className="typing-dots"><i/><i/><i/></div><span>{typing.filter((u) => u !== name).join(', ')} {typing.length === 1 ? 'is' : 'are'} typing</span></div>}{visibleMessages.length === 0 && search && <div className="no-results">No messages match “{search}”.</div>}<div ref={bottomRef}/></div>
  <div className="composer-wrap">{error && <div className="inline-error">{error}<button className="icon-btn" onClick={() => setError('')}><X size={14}/></button></div>}{upload && <div className="upload-chip"><Paperclip size={15}/><span>{upload.name}</span><button className="icon-btn" onClick={() => setUpload(null)} title="Remove file"><X size={15}/></button></div>}<form className="composer" onSubmit={sendMessage}><button type="button" className="composer-tool" title="Attach a file" onClick={() => fileRef.current?.click()}><Paperclip size={19}/></button><input ref={fileRef} type="file" hidden onChange={(e) => setUpload(e.target.files?.[0] || null)} accept="image/png,image/jpeg,image/gif,image/webp,application/pdf,text/plain,application/zip"/><input className="message-input" value={draft} onChange={(e) => onDraft(e.target.value)} placeholder="Write a message..." maxLength={4000} aria-label="Write a message"/><button type="button" className="composer-tool emoji-tool" title="Add a smile" onClick={() => onDraft(draft + ' 😊')}><Smile size={19}/></button><button className="send-btn" type="submit" disabled={sending || (!draft.trim() && !upload)} title="Send message"><Send size={18}/></button></form><div className="composer-hint"><span><kbd>Enter</kbd> to send</span><span>Be kind. Keep it helpful.</span></div></div></section>
  <aside className="details-panel"><div className="details-top"><span>ROOM DETAILS</span><button className="icon-btn" title="More room options"><MoreHorizontal size={20}/></button></div><div className="room-cover"><div className="cover-orbit orbit-one"/><div className="cover-orbit orbit-two"/><div className="cover-center"><MessageCircle size={30}/></div><span className="cover-star star-one">✦</span><span className="cover-star star-two">✧</span></div><div className="room-detail-title"><h3>General chat</h3><span className="public-tag"><Circle size={7} fill="currentColor"/> PUBLIC</span></div><p className="room-description">A shared space for ideas, questions, updates, and everything in between.</p><div className="detail-divider"/><div className="members-heading"><strong>Members</strong><span>{online.length}</span></div><div className="member-list">{online.map((person) => <div className="member-row" key={person}><div className="avatar small" style={{ background: avatarColor(person) }}>{initials(person)}<i/></div><div className="member-name"><strong>{person}{person === name ? ' (you)' : ''}</strong><small>Active now</small></div><span className="member-status"/></div>)}{online.length === 0 && <p className="side-empty">Connecting…</p>}</div><div className="details-footer"><div className="secure-icon">✳</div><div><strong>A little reminder</strong><p>Great chats begin with respect. Make everyone feel welcome.</p></div></div></aside></main>;
}
