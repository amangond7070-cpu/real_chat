import pg from 'pg';
const { Pool } = pg;

export const pool = new Pool({ connectionString: process.env.DATABASE_URL });

export async function initDb() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS messages (
      id BIGSERIAL PRIMARY KEY,
      client_id TEXT UNIQUE,
      sender TEXT NOT NULL,
      body TEXT NOT NULL DEFAULT '',
      file_url TEXT,
      file_name TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      read_by TEXT[] NOT NULL DEFAULT '{}'
    )
  `);
  await pool.query('CREATE INDEX IF NOT EXISTS messages_created_at_idx ON messages (created_at DESC)');
}
