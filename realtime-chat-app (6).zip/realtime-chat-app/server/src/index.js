import 'dotenv/config';
import express from 'express';
import http from 'http';
import cors from 'cors';
import helmet from 'helmet';
import multer from 'multer';
import path from 'path';
import crypto from 'crypto';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { Server } from 'socket.io';
import { pool, initDb } from './db.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const uploadDir = path.resolve(__dirname, '../uploads');
fs.mkdirSync(uploadDir, { recursive: true });
const app = express();
const server = http.createServer(app);
const origin = process.env.CLIENT_ORIGIN || 'http://localhost:5173';
const io = new Server(server, { cors: { origin, methods: ['GET', 'POST'] } });
const port = Number(process.env.PORT || 4000);
const onlineUsers = new Map();

app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));
app.use(cors({ origin }));
app.use(express.json({ limit: '1mb' }));
app.use('/uploads', express.static(uploadDir));

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadDir),
  filename: (_req, file, cb) => {
    const safe = path.basename(file.originalname).replace(/[^a-zA-Z0-9._-]/g, '_').slice(-100);
    cb(null, `${crypto.randomUUID()}-${safe}`);
  }
});
const maxBytes = Math.max(1, Number(process.env.MAX_UPLOAD_MB || 10)) * 1024 * 1024;
const upload = multer({ storage, limits: { fileSize: maxBytes }, fileFilter: (_req, file, cb) => {
  const allowed = /^(image\/(png|jpeg|gif|webp)|application\/pdf|text\/plain|application\/(zip|vnd.openxmlformats-officedocument.wordprocessingml.document))$/i;
  cb(allowed.test(file.mimetype) ? null : new Error('Unsupported file type.'), allowed.test(file.mimetype));
} });

app.get('/api/health', (_req, res) => res.json({ ok: true }));
app.get('/api/messages', async (req, res, next) => {
  try {
    const limit = Math.min(100, Math.max(1, Number(req.query.limit) || 50));
    const result = await pool.query(
      'SELECT id, client_id AS "clientId", sender, body, file_url AS "fileUrl", file_name AS "fileName", created_at AS "createdAt", read_by AS "readBy" FROM (SELECT * FROM messages ORDER BY created_at DESC LIMIT $1) recent ORDER BY created_at ASC',
      [limit]
    );
    res.json(result.rows);
  } catch (err) { next(err); }
});
app.post('/api/upload', (req, res, next) => {
  upload.single('file')(req, res, (err) => {
    if (err) return res.status(400).json({ error: err.message || 'Upload failed' });
    if (!req.file) return res.status(400).json({ error: 'Choose a file first.' });
    res.status(201).json({ url: `/uploads/${req.file.filename}`, name: req.file.originalname, size: req.file.size });
  });
});
app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: 'Something went wrong on the server.' });
});

io.on('connection', (socket) => {
  socket.on('user:join', (rawName) => {
    const name = String(rawName || '').trim().slice(0, 32);
    if (!name) return;
    socket.data.name = name;
    onlineUsers.set(socket.id, name);
    io.emit('presence:update', [...new Set(onlineUsers.values())]);
  });

  socket.on('chat:message', async (payload, ack) => {
    try {
      const sender = String(socket.data.name || '').slice(0, 32);
      const body = String(payload?.body || '').trim().slice(0, 4000);
      const fileUrl = payload?.fileUrl ? String(payload.fileUrl).slice(0, 500) : null;
      const fileName = payload?.fileName ? String(payload.fileName).slice(0, 255) : null;
      if (!sender || (!body && !fileUrl)) return ack?.({ error: 'Message cannot be empty.' });
      const clientId = String(payload?.clientId || crypto.randomUUID()).slice(0, 80);
      const result = await pool.query(
        `INSERT INTO messages (client_id, sender, body, file_url, file_name, read_by)
         VALUES ($1,$2,$3,$4,$5,ARRAY[$2]::text[])
         ON CONFLICT (client_id) DO UPDATE SET client_id=EXCLUDED.client_id
         RETURNING id, client_id AS "clientId", sender, body, file_url AS "fileUrl", file_name AS "fileName", created_at AS "createdAt", read_by AS "readBy"`,
        [clientId, sender, body, fileUrl, fileName]
      );
      const message = result.rows[0];
      io.emit('chat:message', message);
      ack?.({ message });
    } catch (err) { console.error(err); ack?.({ error: 'Could not send message.' }); }
  });

  socket.on('chat:typing', (typing) => {
    if (socket.data.name) socket.broadcast.emit('chat:typing', { name: socket.data.name, typing: Boolean(typing) });
  });

  socket.on('chat:read', async (messageId) => {
    const name = socket.data.name;
    if (!name || !messageId) return;
    try {
      const result = await pool.query(
        `UPDATE messages SET read_by = CASE WHEN $2 = ANY(read_by) THEN read_by ELSE array_append(read_by, $2) END
         WHERE id = $1 RETURNING id, read_by AS "readBy"`, [messageId, name]
      );
      if (result.rows[0]) io.emit('chat:read', { id: result.rows[0].id, readBy: result.rows[0].readBy, reader: name });
    } catch (err) { console.error(err); }
  });

  socket.on('disconnect', () => {
    onlineUsers.delete(socket.id);
    io.emit('presence:update', [...new Set(onlineUsers.values())]);
  });
});

await initDb();
server.listen(port, () => console.log(`Chat server running at http://localhost:${port}`));
