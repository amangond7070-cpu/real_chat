# Orbit Chat — Real-Time Chat App

A full-stack group chat starter made with React, Vite, Node.js, Express, Socket.IO, and PostgreSQL.

## Features
- Live messages with Socket.IO
- Online presence and typing indicators
- Message history stored in PostgreSQL
- Read receipts
- Search message history
- File/image attachments (local disk in development)
- Responsive dark UI

> Important: this starter uses display names instead of real account authentication. Do not launch it for public use with sensitive/private messages until authentication, authorization, upload security, rate limits, and durable file storage are added. On many free hosting services, local uploaded files can disappear after redeploy/restart.

## Requirements
- Node.js 20 or newer
- npm
- PostgreSQL 14 or newer

## 1. Open in VS Code
1. Download and extract this ZIP.
2. In VS Code, choose **File → Open Folder** and select `realtime-chat-app`.
3. Open **Terminal → New Terminal**.

## 2. Create a PostgreSQL database
Create a database named `realtime_chat` using pgAdmin or the PostgreSQL terminal. Example SQL:

```sql
CREATE DATABASE realtime_chat;
```

## 3. Configure the backend
1. Copy `server/.env.example` to `server/.env`.
2. Open `server/.env` and set your PostgreSQL username/password:

```env
PORT=4000
CLIENT_ORIGIN=http://localhost:5173
DATABASE_URL=postgres://postgres:YOUR_PASSWORD@localhost:5432/realtime_chat
MAX_UPLOAD_MB=10
```

Replace `YOUR_PASSWORD` with your own PostgreSQL password. Never commit `.env` to GitHub.

## 4. Install and run
Run from the root project folder:

```bash
npm run install:all
npm run dev
```

Open `http://localhost:5173`. Open it in two separate tabs/windows and enter different display names to test live messaging.

If PowerShell blocks npm scripts, use the VS Code terminal dropdown to select **Command Prompt**, then run the commands there.

## 5. Upload project to GitHub
Create a **new empty repository** on https://github.com/new. Do not add a README or .gitignore there (this project already has them).

In VS Code terminal, from the `realtime-chat-app` root folder, run:

```bash
git init
git add .
git commit -m "Initial real-time chat app"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

Replace the URL with the HTTPS URL of your own GitHub repository. If Git asks you to sign in, complete the browser sign-in prompt. Never put database passwords or API secrets in source files.

For later updates:

```bash
git add .
git commit -m "Update chat app"
git push
```

## 6. Hosting overview
- **PostgreSQL:** create a hosted PostgreSQL database (for example, Neon) and copy its connection string into the backend environment variable `DATABASE_URL`.
- **Backend:** deploy the `server` folder as a Node web service (for example, Render). Set `PORT` if the host requires it, `DATABASE_URL`, `CLIENT_ORIGIN` (your deployed frontend URL), and `MAX_UPLOAD_MB`. Start command: `npm start` from the `server` directory.
- **Frontend:** deploy the `client` folder (for example, Vercel). Build command: `npm run build`; output directory: `dist`. Set `VITE_API_URL` to the deployed backend base URL, without a trailing slash.
- Set the backend `CLIENT_ORIGIN` to the exact deployed frontend URL, then redeploy the backend.
- Test chat using two different browsers/devices.

Hosting providers change their free-plan limits, and free services may sleep. Local disk uploads are not durable on many hosts; use object storage such as S3-compatible storage before relying on uploads in production.

## API
- `GET /api/health` — server health check
- `GET /api/messages?limit=50` — recent message history
- `POST /api/upload` — upload a file (`multipart/form-data`, field name `file`)

## Socket events
- Client to server: `user:join`, `chat:message`, `chat:typing`, `chat:read`
- Server to client: `chat:message`, `presence:update`, `chat:typing`, `chat:read`
